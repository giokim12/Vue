<template>
  <div>
    <button style = "width: 90%;" @click ="orderMenu">장바구니 담기</button>
    <h3>주문 내역</h3>
    <!-- <p>총 {{ totalOrderCount }}건: {{ totalOrderPrice }}원</p> -->
    <div>
      {{ orderList }}
    </div>

  </div>
</template>

<script>
export default {
  name: 'OrderList',
  computed: {
    orderList() {
        return this.$store.state.orderList
    },
    totalOrderCount() {
      return this.$store.getters.totalOrderCount
    },
    totalOrderPrice() {
      return this.$store.getters.totalOrderPrice
    },
    // checkOrder() {
    //     return this.$store.state.orderList
    // }
    
  },
  methods: {
    orderMenu() {
    
        return this.$store.dispatch('orderMenu')
      }
  }
}
</script>

<style>
</style>